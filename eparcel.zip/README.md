# ePARCELSys
eParcelSys is an initiative from ALUMNI to Kolej Vokasional Kuala Selangor to organize students parcels. This system will help the students to understand when and where the parcel is once the item is handed over to the receptionist.
