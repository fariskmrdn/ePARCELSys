

<?php $__env->startSection('title', 'ePARCELSys - Daftar Masuk Parcel'); ?>

<?php $__env->startSection('content'); ?>

    <?php echo $__env->make('layouts.sidebar-admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('layouts.header-admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>



    <!-- [ Main Content ] start -->
    <div class="pc-container">
        <div class="pc-content">
            <!-- [ breadcrumb ] start -->
            <div class="page-header">
                <div class="page-block">
                    <div class="row align-items-center">
                        <div class="col-md-12">
                            <div class="page-header-title">
                                <h2 class="mb-0">Daftar Masuk Parcel</h2>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <div class="row">
                <div class="col-md-12 col-xxl-12">
                    <div class="card statistics-card-1">
                        <div class="card-body">
                            <img src="<?php echo e(URL::asset('assets/images/widget/img-status-2.svg')); ?>" alt="img"
                                class="img-fluid img-bg" />
                            <div class="">
                                <div>
                                    <h5 class="text-muted mb-3">Masukkan atau Imbas No Tracking disini</h5>
                                    <form action="<?php echo e(route('admins.admin.register')); ?>" method="POST">
                                        <?php echo csrf_field(); ?>
                                        <input type="text" name="tracking_no" class="form-control w-100 mb-4" id="trackingNo"
                                            placeholder="Masukkan/Imbas No Tracking">
                                            <script>
                                                $(document).ready(function() {
                                                    $('#trackingNo').focus();
                                                });
                                            </script>
                                            <button class="btn btn-success" type="submit">Daftar Masuk</button>
                                    </form>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <!-- [ breadcrumb ] end -->

            <!-- [ Main Content ] start -->
            
            <!-- [ Main Content ] end -->
        </div>
    </div>
    <!-- [ Main Content ] end -->
    <?php echo $__env->make('layouts.footer-admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin-app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\pc\Desktop\eparcel\ePARCELSys\resources\views/admins/add.blade.php ENDPATH**/ ?>