
<?php $__env->startSection('title', 'eParcel Sys - Carian ' . $search); ?>
<?php $__env->startSection('content'); ?>
    <div id="Content">
        <div class="section" style="padding-top:100px;padding-bottom:100px;background-color:#f8f8f8">
            <div class="container">
                <div class="row" style="padding:30px">
                    <div class="col-12 text-center">
                        <?php if($errors->any()): ?>
                            <div class="alert alert-danger">
                                <ul>
                                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <li><?php echo e($error); ?></li>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </ul>
                            </div>
                        <?php endif; ?>
                    </div>
                    <div class="col-12">
                        <hr class="no_line" style="margin:0 auto 50px">
                        <?php if(session('parcels')): ?>
                            <?php $no = 1; ?>

                            <h2 class="text-center">Hasil Carian: <?php echo e($search); ?></h2>
                            <?php $__currentLoopData = session('parcels'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $parcel): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="card mb-2">
                                    <div class="card-body">
                                        <p>
                                            <strong>No Tracking :</strong><?php echo e($parcel->tracking); ?>

                                        </p>
                                        <p>
                                            <strong>Nama Penerima :</strong><?php echo e($parcel->receiver); ?>

                                        </p>
                                        <p>
                                            <strong>No Siri Ketibaan   :</strong><?php echo e($parcel->serial_no); ?>

                                        </p>
                                        <p>
                                            <strong>Tarikh dan Masa Ketibaan  
                                                :</strong><?php echo e(\Carbon\Carbon::parse($parcel->created_at)->format('d/m/Y h:i A')); ?>

                                        </p>
                                        <p>
                                            <?php if($parcel->status == '1'): ?>
                                            Status : <span class="btn btn-success">Sedia Dituntut</span>
                                                <?php else: ?>
                                            Status : <span class="btn btn-danger">Telah Dituntut</span>

                                            <?php endif; ?>
                                        </p>
                                    </div>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php else: ?>
                            <p>Harap Maaf. Tiada Carian Dijumpai. Sila Cuba Sekali Lagi.</p>
                        <?php endif; ?>
                        <a class="btn btn-primary" href="<?php echo e(route('index')); ?>">Kembali</a>
                    </div>

                </div>
            </div>
        </div>


    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\pc\Desktop\eparcel\ePARCELSys\resources\views/search.blade.php ENDPATH**/ ?>