<footer class="pc-footer">
    <div class="footer-wrapper container-fluid">
        <div class="row">
            <div class="col-sm-6 my-1">
                <p class="m-0">Hak cipta terpelihara Kolej Vokasional Kuala Selangor &copy; <?php echo e(now()->year); ?></p>
            </div>
            <div class="col-sm-6 ms-auto my-1">
                <ul class="list-inline footer-link mb-0 justify-content-sm-end d-flex">
                    <li class="list-inline-item">Shine With Skills</li>
                </ul>
            </div>
        </div>
    </div>
</footer><?php /**PATH C:\Users\pc\Desktop\eparcel\ePARCELSys\resources\views/layouts/footer-admin.blade.php ENDPATH**/ ?>