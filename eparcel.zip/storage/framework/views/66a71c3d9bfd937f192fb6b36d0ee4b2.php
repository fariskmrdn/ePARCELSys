

<?php $__env->startSection('title', 'ePARCELSys - Dashboard'); ?>

<?php $__env->startSection('content'); ?>

    <?php echo $__env->make('layouts.sidebar-admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('layouts.header-admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>



    <!-- [ Main Content ] start -->
    <div class="pc-container">
        <div class="pc-content">
            <!-- [ breadcrumb ] start -->
            <div class="page-header">
                <div class="page-block">
                    <div class="row align-items-center">
                        <div class="col-md-12">
                            <div class="page-header-title">
                                <h2 class="mb-0">Dashboard</h2>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <!-- [ breadcrumb ] end -->

            <!-- [ Main Content ] start -->
            <div class="row">
                <!-- [ Row 1 ] start -->
                <div class="col-md-12 col-xxl-6">
                    <div class="card statistics-card-1">
                        <div class="card-body">
                            <img src="<?php echo e(URL::asset('assets/images/widget/img-status-2.svg')); ?>" alt="img"
                                class="img-fluid img-bg" />
                            <div class="d-flex align-items-center">
                                <div class="avtar bg-brand-color-1 text-white me-3">
                                    <i class="ph-duotone ph-package f-26"></i>
                                </div>
                                <div>
                                    <p class="text-muted mb-0">Barangan Terkumpul (Tidak Dituntut)</p>
                                    <div class="d-flex align-items-end">
                                        <h2 class="mb-0 f-w-500"><?php echo e($countItem); ?></h2>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                
                <div class="col-md-6 col-xxl-6">
                    <div class="card statistics-card-1">
                        <div class="card-body">
                            <img src="<?php echo e(URL::asset('assets/images/widget/img-status-3.svg')); ?>" alt="img"
                                class="img-fluid img-bg" />
                            <div class="d-flex align-items-center">
                                <div class="avtar bg-brand-color-3 text-white me-3">
                                    <i class="ph-duotone ph-users-four f-26"></i>
                                </div>
                                <div>
                                    <p class="text-muted mb-0">Akaun Pelajar Berdaftar</p>
                                    <div class="d-flex align-items-end">
                                        <h2 class="mb-0 f-w-500"><?php echo e($countAccounts); ?></h2>

                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <!-- [ Row 1 ] end -->
                <!-- [ Row 2 ] start -->
                <div class="col-md-6">
                    <div class="card table-card">
                        <div class="card-header">
                            <h5>5 Barang Yang Telah Didaftarkan</h5>
                        </div>
                        <div class="card-body py-3 px-0">
                            <div class="table-responsive affiliate-table">
                                <table class="table table-hover table-borderless mb-0">
                                    <tbody>
                                        <?php $__currentLoopData = $showFiveInventory; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $inv): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr>
                                                <td>
                                                    <div class="d-flex align-items-center">
                                                        <img src="<?php echo e(URL::asset('assets/images/user/scanner.png')); ?>"
                                                            alt="" class="img-fluid wid-30 rounded-1" />
                                                        <h6 class="mb-0 ms-2"><?php echo e($inv->tracking_no); ?></h6>
                                                    </div>
                                                </td>
                                                <td><?php echo e(\Carbon\Carbon::parse($inv->created_at)->format('d/m/Y h:i A')); ?>

                                                </td>
                                            </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-md-6">
                    <div class="card table-card">
                        <div class="card-header">
                            <h5>5 Barang Yang Telah Dituntut</h5>
                        </div>
                        <div class="card-body py-3 px-0">
                            <div class="table-responsive">
                                <table class="table table-hover table-borderless mb-0">
                                    <tbody>
                                        <?php $__currentLoopData = $showFiveClaimedItem; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr>
                                                <td>
                                                    <div class="d-flex align-items-center">
                                                        <img src="<?php echo e(URL::asset('assets/images/user/parcel_check.png')); ?>"
                                                            alt="" class="img-fluid wid-30 rounded-1" />
                                                        <h6 class="mb-0 ms-2"><?php echo e($item->tracking); ?></h6>
                                                    </div>
                                                </td>
                                                <td><?php echo e(\Carbon\Carbon::parse($item->updated_at)->format('d/m/Y h:i A')); ?>

                                                </td>
                                            </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
                <!-- [ Row 2 ] end -->
            </div>
            <!-- [ Main Content ] end -->
        </div>
    </div>
    <!-- [ Main Content ] end -->
    <?php echo $__env->make('layouts.footer-admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin-app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\pc\Desktop\eparcel\ePARCELSys\resources\views/admins/dashboard.blade.php ENDPATH**/ ?>