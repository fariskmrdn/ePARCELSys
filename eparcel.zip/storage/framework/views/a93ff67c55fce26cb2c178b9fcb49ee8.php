<!DOCTYPE html>
<html lang="en">
<!-- [Head] start -->

<head>
    <title><?php echo $__env->yieldContent('title'); ?></title>
    <!-- [Meta] -->
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=0, minimal-ui" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="description"
        content="Light Able admin and dashboard template offer a variety of UI elements and pages, ensuring your admin panel is both fast and effective." />
    <meta name="author" content="phoenixcoded" />
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>

    <!-- [Favicon] icon -->
    <link rel="icon" href="<?php echo e(URL::asset('images/kv.png')); ?>" type="image/x-icon" />
    <!-- [Google Font : Public Sans] icon -->
    <link href="https://fonts.googleapis.com/css2?family=Public+Sans:wght@400;500;600;700&display=swap"
        rel="stylesheet">
    <link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/1.11.5/css/jquery.dataTables.min.css" />

    <!-- [Tabler Icons] https://tablericons.com -->
    <link rel="stylesheet" href="<?php echo e(URL::asset('assets/afonts/tabler-icons.min.css')); ?>">
    <!-- [Feather Icons] https://feathericons.com -->
    <link rel="stylesheet" href="<?php echo e(URL::asset('assets/fonts/feather.css')); ?>">
    <!-- [Font Awesome Icons] https://fontawesome.com/icons -->
    <link rel="stylesheet" href="<?php echo e(URL::asset('assets/fonts/fontawesome.css')); ?>">
    <!-- [Material Icons] https://fonts.google.com/icons -->
    <link rel="stylesheet" href="<?php echo e(URL::asset('assets/fonts/material.css')); ?>">
    <!-- [Template CSS Files] -->
    <link rel="stylesheet" href="<?php echo e(URL::asset('assets/css/style.css')); ?>" id="main-style-link">
    <link rel="stylesheet" href="<?php echo e(URL::asset('assets/css/style-preset.css')); ?>">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/sweetalert2@11/dist/sweetalert2.min.css">

</head>
<!-- [Head] end -->
<!-- [Body] Start -->

<body data-pc-preset="preset-1" data-pc-sidebar-theme="light" data-pc-sidebar-caption="true" data-pc-direction="ltr"
    data-pc-theme="light">
    <!-- [ Pre-loader ] start -->
    <div class="loader-bg">
        <div class="loader-track">
            <div class="loader-fill"></div>
        </div>
    </div>

    <?php echo $__env->yieldContent('content'); ?>



    <!-- Required Js -->

    <script src="<?php echo e(asset('assets/js/plugins/popper.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/plugins/simplebar.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/plugins/bootstrap.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/fonts/custom-font.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/pcoded.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/plugins/feather.min.js')); ?>"></script>
    <script type="text/javascript" src="https://cdn.datatables.net/1.11.5/js/jquery.dataTables.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11/dist/sweetalert2.min.js"></script>

    <?php if(session()->has('icon')): ?>
        <script>
            Swal.fire({
                icon: '<?php echo e(session('icon')); ?>',
                title: '<?php echo e(session('title')); ?>',
                text: '<?php echo e(session('text')); ?>'
            });
        </script>
    <?php endif; ?>
</body>
<!-- [Body] end -->

</html>
<?php /**PATH C:\Users\pc\Desktop\eparcel\ePARCELSys\resources\views/layouts/admin-app.blade.php ENDPATH**/ ?>