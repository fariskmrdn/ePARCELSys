

<?php $__env->startSection('title', 'ePARCELSys - Log Masuk Admin'); ?>

<?php $__env->startSection('content'); ?>
    <div class="auth-main v1">
        <div class="auth-wrapper">
            <div class="auth-form">
                <div class="card my-5">
                    <form action="<?php echo e(route('admin.login')); ?>" method="POST">
                        <?php echo csrf_field(); ?>
                        <div class="card-body">
                            <div class="text-center">
                                <img src="<?php echo e(URL::asset('images/eparcel.png')); ?>" alt="images" class="img-fluid mb-3">
                                <h4 class="f-w-500 mb-3">Log Masuk Admin</h4>
                            </div>
                            <div class="mb-3">
                                <input type="text" class="form-control" id="floatingInput"
                                    placeholder="Masukkan nama pengguna" name="username">
                            </div>
                            <div class="mb-3">
                                <input type="password" class="form-control" id="floatingInput1"
                                    placeholder="Masukkan kata laluan" name="password">
                            </div>
                            <div class="d-grid mt-4">
                                <button type="submit" class="btn btn-primary">Log Masuk</button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin-app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\pc\Desktop\eparcel\ePARCELSys\resources\views/admins/login.blade.php ENDPATH**/ ?>